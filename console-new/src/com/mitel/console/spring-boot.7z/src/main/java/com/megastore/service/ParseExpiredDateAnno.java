package com.megastore.service;

import java.lang.annotation.Annotation;
import java.text.SimpleDateFormat;

import com.megastore.domain.PriceDTO;

public class ParseExpiredDateAnno {

	final static String DATE_FORMAT = "yyyy-MM-dd";
	final static SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

	public static void execute(PriceDTO dto){
		System.out.println("Testing..."); 
		try {
			Class<PriceDTO> obj = PriceDTO.class;
			if (obj.isAnnotationPresent(ExpiredDate.class)) {
				Annotation[] annotation = obj.getAnnotations();
				for (Annotation annotation2 : annotation) {
					ExpiredDate expiredAnnotation = (ExpiredDate) annotation2;
					dto.setStartDate(sdf.parse(expiredAnnotation.startDate().toString()));
					dto.setEndDate(sdf.parse(expiredAnnotation.endDate().toString()));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}