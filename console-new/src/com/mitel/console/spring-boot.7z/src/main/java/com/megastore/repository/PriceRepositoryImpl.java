package com.megastore.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.megastore.domain.Price;

public class PriceRepositoryImpl implements PriceRepositoryCustom {

	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Price> find() {
		return this.entityManager.createQuery(
				"select p from Price p where p.endDate >= '" + sdf.format(date)
						+ "'").getResultList();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Price> findByProduct(int id, int size) {
		List<Price> prices;
		Query query = this.entityManager
				.createQuery("select p from Price p where p.endDate >= '"
						+ sdf.format(date) + "' and p.product.id = " + id);
		query.setFirstResult(0);
		query.setMaxResults(size > 10 ? size : 10);
		prices = query.getResultList();
		return prices;

	}
}
