package com.megastore.controller;

import java.util.List;

import javax.inject.Inject;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.megastore.domain.Price;
import com.megastore.domain.PriceDTO;
import com.megastore.domain.Product;
import com.megastore.domain.ProductDTO;
import com.megastore.service.ParseExpiredDateAnno;
import com.megastore.service.PriceService;
import com.megastore.service.ProductService;

@RestController
public class ProductController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ProductController.class);
	@Inject
	private ProductService productService;

	@Inject
	private PriceService priceService;

	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public Product addProduct(@RequestBody @Valid final ProductDTO productDto) {
		LOGGER.debug("Received request to create the {}", productDto);
		// Will change some efficient way to fill actual Product entity bean
		Product product = new Product();
		product.setDescription(productDto.getDescription());
		product.setImage(productDto.getImage());
		product.setName(productDto.getName());
		if (productDto.getRole().toUpperCase().equals("PM")) {
			return productService.save(product);
		} else {
			return product; // may be some re-directional mechanism for
							// providing messages
		}
	}

	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public List<Product> listProducts(
			@RequestParam(value = "size", required = false) Integer size) {
		LOGGER.debug("Received request to list all products");
		return productService.getList(size);
	}

	@RequestMapping(value = "/products/{productId}/prices", method = RequestMethod.POST)
	public List<Price> addPrices(@PathVariable("productId") int productId,
			@RequestBody @Valid final PriceDTO dto) {
		ParseExpiredDateAnno.execute(dto);
		Price priceObj = new Price();
		priceObj.setAmount(dto.getAmount());
		priceObj.setCurrency(dto.getCurrency());
		priceObj.setStartDate(dto.getStartDate());
		priceObj.setEndDate(dto.getEndDate());
		priceObj.setProduct(productService.getProductById(productId));
		LOGGER.debug("Received request to add price for product" + priceObj);
		priceService.save(priceObj);
		return priceService.getValidPrices();
	}

	@RequestMapping(value = "/products/{productId}/prices", method = RequestMethod.GET)
	public List<Price> getValidPrices(@PathVariable("productId") int productId,
			@RequestParam(value = "size", required = false) Integer size) {
		LOGGER.debug("Received request to list all products");
		return priceService.getPriceByProductId(productId, size);
	}
}
