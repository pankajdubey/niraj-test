package com.megastore.service;

import java.util.List;

import com.megastore.domain.Price;

public interface PriceService {

    Price save(Price price);

    List<Price> getValidPrices();
    List<Price> getPriceByProductId(int pId, Integer size);

}
