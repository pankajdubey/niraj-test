package com.megastore.service;

import java.util.List;

import com.megastore.domain.Product;

public interface ProductService {

	Product save(Product product);

	List<Product> getList(Integer size);

	Product getProductById(int pId);

}
