package com.megastore.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.inject.Inject;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import com.megastore.domain.Product;
import com.megastore.repository.ProductRepository;

@Service
@Validated
public class ProductServiceImpl implements ProductService {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ProductServiceImpl.class);
	private final ProductRepository productRepository;

	@Inject
	public ProductServiceImpl(final ProductRepository repository) {
		this.productRepository = repository;
	}

	@Override
	@Transactional
	public Product save(@NotNull @Valid final Product product) {
		LOGGER.debug("Creating {}", product);
		return productRepository.save(product);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Product> getList(Integer size) {
		LOGGER.debug("Retrieving all products");
		PageRequest request;
		if (size == null) {
			request = new PageRequest(0, productRepository.findAll().size());
		} else if (size.intValue() < 10) {
			request = new PageRequest(0, 10);
		} else
			request = new PageRequest(0, size.intValue());

		Iterator<Product> itr = productRepository.findAll(request).iterator();
		ArrayList<Product> products = new ArrayList<>();
		while (itr.hasNext()) {
			products.add(itr.next());
		}
		return products;
	}

	@Override
	@Transactional(readOnly = true)
	public Product getProductById(int pId) {
		LOGGER.debug("Retrieving a products of ID: " + pId);
		return productRepository.findOne(pId);
	}

}
