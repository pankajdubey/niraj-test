package com.megastore.service;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface ExpiredDate {

	ValidDateEnum startDate() default ValidDateEnum.START_DATE;

	ValidDateEnum endDate() default ValidDateEnum.END_DATE;

}
