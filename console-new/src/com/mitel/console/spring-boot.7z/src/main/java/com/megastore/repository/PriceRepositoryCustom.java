package com.megastore.repository;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.megastore.domain.Price;

public interface PriceRepositoryCustom {
	public List<Price> find();

	public List<Price> findByProduct(int id, int size);

	final static String DATE_FORMAT = "yyyy-MM-dd";
	final static SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
	final static Date date = new Date();
}
