package com.megastore.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public enum ValidDateEnum {

	START_DATE {
		@Override
		public String toString() {
			return sdf.format(date);
		}
	},
	END_DATE {
		@Override
		public String toString() {
			return sdf.format(new CalculatedEndDate(date).getDate());
		}
	};

	final static String DATE_FORMAT = "yyyy-MM-dd";
	final static SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
	final static Date date = new Date();

	// just for testing purpose
	public static void main(String[] args) {
		System.out.println(ValidDateEnum.START_DATE);
		System.out.println(ValidDateEnum.END_DATE);
	}
}

class CalculatedEndDate {
	Date date;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public CalculatedEndDate(Date date) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		calendar.add(Calendar.DATE, 30);
		this.date = calendar.getTime();
	}
}