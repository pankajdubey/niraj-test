package com.megastore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.megastore.domain.Price;


public interface PriceRepository extends JpaRepository<Price, Integer>, PriceRepositoryCustom {
}
