package com.megastore.service;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import com.megastore.domain.Price;
import com.megastore.repository.PriceRepository;

@Service
@Validated
public class PriceServiceImpl implements PriceService {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(PriceServiceImpl.class);
	private final PriceRepository priceRepository;

	@Inject
	public PriceServiceImpl(final PriceRepository repository) {
		this.priceRepository = repository;
	}

	@Override
	@Transactional
	public Price save(@NotNull @Valid final Price price) {
		LOGGER.debug("Creating {}", price);
		return priceRepository.save(price);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Price> getValidPrices() {
		LOGGER.debug("Retrieving all valid prices for a product");
		return priceRepository.find();
	}

	@Override
	@Transactional(readOnly = true)
	public List<Price> getPriceByProductId(int pId, Integer size) {
		LOGGER.debug("Retrieving all valid prices for a product");
		List<Price> prices = new ArrayList<>();
		if (size == null) {
			prices = priceRepository.find();
		} else if (size.intValue() < 10) {
			prices = priceRepository.findByProduct(pId, 10);
		}else {
			prices = priceRepository.findByProduct(pId, size.intValue());
		}
		return prices;
	}
}
